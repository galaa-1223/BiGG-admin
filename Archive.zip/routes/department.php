<?php

use Illuminate\Support\Facades\Route;

Route::get('department/login','Auth\DepartmentAuthController@getLogin')->name('departmentLogin');
Route::post('department/login', 'Auth\DepartmentAuthController@postLogin')->name('departmentLoginPost');
Route::get('department/logout', 'Auth\DepartmentAuthController@logout')->name('departmentLogout');

Route::group(['prefix' => 'department','middleware' => 'departmentauth'], function () {
	// Department Dashboard
	Route::get('dashboard','DepartmentController@dashboard')->name('dashboard');	
});
